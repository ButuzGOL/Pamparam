<?php

include('FileController.php');
class FilemController extends FileController
{
    const PAGE_SIZE=50;
    public $layout='filem';
    
}
