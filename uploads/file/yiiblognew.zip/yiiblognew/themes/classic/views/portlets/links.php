<ul>
<li><a href="http://www.yiiframework.com/">Yii</a>
<li><a href="http://phpspot.net/php/codeconv/">PHP code converter</a>
</ul>
