<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1>Error</h1>
<p><?php echo $error?></p>