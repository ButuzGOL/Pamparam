<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'Группа "%s" не определена Вашей конфигурацией.',
	'extension_not_loaded' => 'Расширение PHP "%s" должно быть загружено для использования этого драйвера.',
	'unwritable'           => 'Целевая директория хранения кеша, %s, не доступна для записи.',
	'resources'            => 'Кеширование ресурсов невозможно, так как ресурсы не могут быть сериализованы.',
	'driver_error'         => '%s',
);
