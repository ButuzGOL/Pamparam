<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="widget">
	<h2><?php echo __('Tag cloud') ?></h2>
	<p>
		<?php echo $tags ?>
	</p>
</div>