<?php defined('SYSPATH') or die('No direct script access.');

$lang = array
(
	'error_msg'			=> 'Invalid',
	'required_msg'		=> 'Required',
	'invalid_file'		=> 'Not a valid file',
	'invalid_type'		=> 'Invalid format',
	'too_large'			=> 'File exceeds size limit'
);