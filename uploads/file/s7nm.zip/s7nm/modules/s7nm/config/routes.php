<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * @package  Core
 *
 * Default route to use when no URI segments are available.
 */
$config['_default'] = 'none';

/**
 * Default route to use for administration
 */
$config['admin'] = 'admin/page';
