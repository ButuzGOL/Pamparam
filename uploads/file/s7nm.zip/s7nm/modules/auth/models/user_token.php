<?php defined('SYSPATH') OR die('No direct access allowed.');

class User_Token_Model extends Auth_User_Token_Model {

	// This class can be replaced or extended

} // End User Token Model