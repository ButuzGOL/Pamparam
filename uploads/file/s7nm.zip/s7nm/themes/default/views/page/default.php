<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="entry">
	<div class="entrytitle">
		<h2><?php echo $page->title ?></h2>
	</div>
	<?php echo $page->content ?>
</div>