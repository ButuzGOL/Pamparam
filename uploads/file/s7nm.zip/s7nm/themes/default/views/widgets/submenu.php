<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="widget">
	<h2><?php echo __('Submenu') ?></h2>
	<?php echo $menu ?>
</div>