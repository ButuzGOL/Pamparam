<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<div class="widget">
	<h2><?php echo $title ?></h2>
	<p><?php echo $content ?></p>
</div>