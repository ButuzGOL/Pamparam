<?php /* Smarty version 2.6.19, created on 2010-09-08 12:50:20
         compiled from footer.light.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'hook', 'footer.light.tpl', 2, false),)), $this); ?>
</div>
<?php echo smarty_function_hook(array('run' => 'body_end'), $this);?>

</body>
</html>