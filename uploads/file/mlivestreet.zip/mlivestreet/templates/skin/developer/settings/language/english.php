<?php

return array(
	'clean_join_leave' => 'Join/Leave',
	'clean_join' => 'join',
	'clean_leave' => 'leave',
	'clean_posts' => 'Posts',
	'clean_blog_closed' => 'Private blog',
	'blog_menu_top' => 'Rating',
	'talk_favourite_empty' => 'No letters to favorites',
	'comment_fold' => 'collapse thread',
	'comment_unfold' => 'expand thread',
);

?>