<?php

return array(
	'clean_join_leave' => 'Вступить/Покинуть',
	'clean_join' => 'вступить',
	'clean_leave' => 'покинуть',
	'clean_posts' => 'Посты',
	'clean_blog_closed' => 'Закрытый блог',
	'blog_menu_top' => 'Рейтинг',
	'talk_favourite_empty' => 'Нет писем в избранном',
	'comment_fold' => 'свернуть ветку',
	'comment_unfold' => 'развернуть ветку',
);

?>