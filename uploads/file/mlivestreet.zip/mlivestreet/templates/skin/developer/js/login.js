function showLoginForm() {
	$$('.login-form').setStyle('display', 'block');
}

function hideLoginForm() {
	$$('.login-form').setStyle('display', 'none');
}

var winFormLogin=false;