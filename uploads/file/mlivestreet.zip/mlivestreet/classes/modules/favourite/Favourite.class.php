<?php
/*-------------------------------------------------------
*
*   LiveStreet Engine Social Networking
*   Copyright © 2008 Mzhelskiy Maxim
*
*--------------------------------------------------------
*
*   Official site: www.livestreet.ru
*   Contact e-mail: rus.engine@gmail.com
*
*   GNU General Public License, version 2:
*   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*
---------------------------------------------------------
*/

/**
 * Модуль для работы с голосованиями
 *
 */
class ModuleFavourite extends Module {		
	protected $oMapper;	
		
	/**
	 * Инициализация
	 *
	 */
	public function Init() {		
		$this->oMapper=Engine::GetMapper(__CLASS__);
	}
	
	/**
	 * Получает информацию о том, найден ли таргет в избранном или нет
	 *
	 * @param  string $sTargetId
	 * @param  string $sTargetType
	 * @param  string $sUserId
	 * @return ModuleFavourite_EntityFavourite|null
	 */
	public function GetFavourite($sTargetId,$sTargetType,$sUserId) {
		$data=$this->GetFavouritesByArray($sTargetId,$sTargetType,$sUserId);
		return (isset($data[$sTargetId]))
			? $data[$sTargetId]
			: null;
	}
	
	/**
	 * Получить список избранного по списку айдишников
	 *
	 * @param  array  $aTargetId
	 * @param  string $sTargetType
	 * @param  string $sUserId
	 * @return array
	 */
	public function GetFavouritesByArray($aTargetId,$sTargetType,$sUserId) {
		if (!$aTargetId) {
			return array();
		}	
		if (Config::Get('sys.cache.solid')) {
			return $this->GetFavouritesByArraySolid($aTargetId,$sTargetType,$sUserId);
		}
		if (!is_array($aTargetId)) {
			$aTargetId=array($aTargetId);
		}
		$aTargetId=array_unique($aTargetId);
		$aFavourite=array();
		$aIdNotNeedQuery=array();
		/**
		 * Делаем мульти-запрос к кешу
		 */
		$aCacheKeys=func_build_cache_keys($aTargetId,"favourite_{$sTargetType}_",'_'.$sUserId);
		if (false !== ($data = $this->Cache_Get($aCacheKeys))) {			
			/**
			 * проверяем что досталось из кеша
			 */
			foreach ($aCacheKeys as $sValue => $sKey ) {
				if (array_key_exists($sKey,$data)) {	
					if ($data[$sKey]) {
						$aFavourite[$data[$sKey]->getTargetId()]=$data[$sKey];
					} else {
						$aIdNotNeedQuery[]=$sValue;
					}
				} 
			}
		}
		/**
		 * Смотрим чего не было в кеше и делаем запрос в БД
		 */		
		$aIdNeedQuery=array_diff($aTargetId,array_keys($aFavourite));		
		$aIdNeedQuery=array_diff($aIdNeedQuery,$aIdNotNeedQuery);		
		$aIdNeedStore=$aIdNeedQuery;
		if ($data = $this->oMapper->GetFavouritesByArray($aIdNeedQuery,$sTargetType,$sUserId)) {
			foreach ($data as $oFavourite) {
				/**
				 * Добавляем к результату и сохраняем в кеш
				 */
				$aFavourite[$oFavourite->getTargetId()]=$oFavourite;
				$this->Cache_Set($oFavourite, "favourite_{$oFavourite->getTargetType()}_{$oFavourite->getTargetId()}_{$sUserId}", array(), 60*60*24*7);
				$aIdNeedStore=array_diff($aIdNeedStore,array($oFavourite->getTargetId()));
			}
		}
		/**
		 * Сохраняем в кеш запросы не вернувшие результата
		 */
		foreach ($aIdNeedStore as $sId) {
			$this->Cache_Set(null, "favourite_{$sTargetType}_{$sId}_{$sUserId}", array(), 60*60*24*7);
		}		
		/**
		 * Сортируем результат согласно входящему массиву
		 */
		$aFavourite=func_array_sort_by_keys($aFavourite,$aTargetId);
		return $aFavourite;		
	}
    /**
	 * Получить список избранного по списку айдишников, но используя единый кеш
	 *
	 * @param  array  $aTargetId
	 * @param  string $sTargetType
	 * @param  string $sUserId
	 * @return array
	 */
	public function GetFavouritesByArraySolid($aTargetId,$sTargetType,$sUserId) {
		if (!is_array($aTargetId)) {
			$aTargetId=array($aTargetId);
		}
		$aTargetId=array_unique($aTargetId);
		$aFavourites=array();
		$s=join(',',$aTargetId);
		if (false === ($data = $this->Cache_Get("favourite_{$sTargetType}_{$sUserId}_id_{$s}"))) {
			$data = $this->oMapper->GetFavouritesByArray($aTargetId,$sTargetType,$sUserId);
			foreach ($data as $oFavourite) {
				$aFavourites[$oFavourite->getTargetId()]=$oFavourite;
			}
			$this->Cache_Set($aFavourites, "favourite_{$sTargetType}_{$sUserId}_id_{$s}", array("favourite_{$sTargetType}_change_user_{$sUserId}"), 60*60*24*1);
			return $aFavourites;
		}
		return $data;
	}
	/**
	 * Возвращает число таргетов определенного типа в избранном по ID пользователя
	 *
	 * @param  string $sUserId
	 * @param  string $sTargetType
	 * @return array
	 */
	public function GetCountFavouritesByUserId($sUserId,$sTargetType,$aExcludeTarget=array()) {
		$s=serialize($aExcludeTarget);
		if (false === ($data = $this->Cache_Get("{$sTargetType}_count_favourite_user_{$sUserId}_{$s}"))) {
			$data = $this->oMapper->GetCountFavouritesByUserId($sUserId,$sTargetType,$aExcludeTarget);
			$this->Cache_Set(
				$data,
				"{$sTargetType}_count_favourite_user_{$sUserId}_{$s}",
				array(
					"favourite_{$sTargetType}_change",
					"favourite_{$sTargetType}_change_user_{$sUserId}"
				),
				60*60*24*1
			);
		}
		return $data;
	}
    /**
	 * Возвращает число топиков в открытых блогах
	 * из избранного по ID пользователя
	 *
	 * @param  string $sUserId
	 * @return array
	 */
	public function GetCountFavouriteOpenTopicsByUserId($sUserId) {
		if (false === ($data = $this->Cache_Get("topic_count_favourite_user_{$sUserId}_open"))) {
			$data = $this->oMapper->GetCountFavouriteOpenTopicsByUserId($sUserId);
			$this->Cache_Set(
				$data,
				"topic_count_favourite_user_{$sUserId}_open",
				array(
					"favourite_topic_change",
					"favourite_topic_change_user_{$sUserId}"
				),
				60*60*24*1
			);
		}
		return $data;
	}
    /**
	 * Возвращает число комментариев к открытым блогам в избранном по ID пользователя
	 *
	 * @param  string $sUserId
	 * @return array
	 */
	public function GetCountFavouriteOpenCommentsByUserId($sUserId) {
		if (false === ($data = $this->Cache_Get("comment_count_favourite_user_{$sUserId}_open"))) {
			$data = $this->oMapper->GetCountFavouriteOpenCommentsByUserId($sUserId);
			$this->Cache_Set(
				$data,
				"comment_count_favourite_user_{$sUserId}_open",
				array(
					"favourite_comment_change",
					"favourite_comment_change_user_{$sUserId}"
				),
				60*60*24*1
			);
		}
		return $data;
	}
}
?>