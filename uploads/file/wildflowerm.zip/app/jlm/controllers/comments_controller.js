$.jlm.bind('comments.admin_index, comments.admin_spam', function () {
    
    $.jlm.components.inplaceEdit.startup();
    
});