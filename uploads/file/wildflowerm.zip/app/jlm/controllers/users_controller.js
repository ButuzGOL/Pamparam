$.jlm.bind('wild_users.wf_change_password', function() {

    $('form').clearForm();
	
});
