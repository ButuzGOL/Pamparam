<?php
class WildWidget extends AppModel {

}