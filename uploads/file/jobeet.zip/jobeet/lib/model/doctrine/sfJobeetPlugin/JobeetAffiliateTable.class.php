<?php

class JobeetAffiliateTable extends PluginJobeetAffiliateTable
{
}
