<?php

class JobeetCategoryTable extends PluginJobeetCategoryTable
{
}
