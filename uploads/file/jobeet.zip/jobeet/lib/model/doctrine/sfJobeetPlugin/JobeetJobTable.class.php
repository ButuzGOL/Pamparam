<?php

class JobeetJobTable extends PluginJobeetJobTable
{
}
