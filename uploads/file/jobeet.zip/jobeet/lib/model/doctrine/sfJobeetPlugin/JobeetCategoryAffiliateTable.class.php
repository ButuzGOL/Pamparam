<?php

class JobeetCategoryAffiliateTable extends PluginJobeetCategoryAffiliateTable
{
}
