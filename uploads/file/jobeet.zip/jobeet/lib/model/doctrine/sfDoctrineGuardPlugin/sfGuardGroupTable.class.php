<?php

class sfGuardGroupTable extends PluginsfGuardGroupTable
{
}
