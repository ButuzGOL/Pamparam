<?php

class sfGuardGroupPermissionTable extends PluginsfGuardGroupPermissionTable
{
}
