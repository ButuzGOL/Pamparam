<?php

class sfGuardPermissionTable extends PluginsfGuardPermissionTable
{
}
