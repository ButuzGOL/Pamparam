<?php

class sfGuardUserPermissionTable extends PluginsfGuardUserPermissionTable
{
}
