<?php

abstract class PluginJobeetCategoryAffiliateTable extends Doctrine_Table
{
}
